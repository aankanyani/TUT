﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace test4.Models.AdoNet
{
    public class EditAddressData
    {
        private string _connectionString;
        public EditAddressData()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
        }
        public ViewAddress EditAddrUser(int id)
        {
            var response = new ViewAddress();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {

                var query = "SELECT * FROM TestOrders WHERE orderID = '" + id + "'";
                using (SqlCommand cmd = new SqlCommand(query))
                {

                    cmd.Connection = con;
                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                response.orderID = reader[0].ToString();
                                response.date = reader[1].ToString();
                                response.status = reader[2].ToString();
                                response.description = reader[3].ToString();
                                response.item = reader[4].ToString();
                                response.itemCategory = reader[5].ToString();
                                response.quantity = reader[6].ToString();
                                response.total = reader[7].ToString();
                            }
                        }
                    }
                }

            }
            return response;
        }
    }
}