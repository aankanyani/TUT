﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace test4.Models.AdoNet
{
    public class ViewAddressData
    {
        private string _connectionString;
        public ViewAddressData()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
        }


        public List<ViewAddress> viewAddressDet(int id)
        {
            try
            {
                var response = new List<ViewAddress>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    var query = "select * from TestOrders  WHERE UserID = '" + id + "'";
                    using (SqlCommand cmd = new SqlCommand(query))
                    {
                        cmd.Connection = con;
                        con.Open();

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    response.Add(new ViewAddress
                                    {
                                        orderID = reader[0].ToString(),
                                        date = reader[1].ToString(),
                                        status = reader[2].ToString(),
                                        description = reader[3].ToString(),
                                        item = reader[4].ToString(),
                                        itemCategory = reader[5].ToString(),
                                        quantity = reader[6].ToString(),
                                        total = reader[7].ToString()
                                    });
                                }
                            }
                        }

                    }

                }

                return response;

            }
            catch
            {

                throw;
            }
        }
    }
}