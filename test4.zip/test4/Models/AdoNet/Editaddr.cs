﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace test4.Models.AdoNet
{
    public class Editaddr
    {
        private string _connectionString;
        public Editaddr()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
        }
        public ViewAddress Editaddresses(ViewAddress ViewAddress)
        {
            ViewAddress view = new ViewAddress();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {

                var query = "UPDATE TestOrders SET date = '" + ViewAddress.date + "', status = '" + ViewAddress.status + "', description = '" + ViewAddress.description + "', item = '" + ViewAddress.item + "', itemCategory = '" + ViewAddress.itemCategory + "', quantity = '" + ViewAddress.quantity + "', total = '" + ViewAddress.total + "'";
                using (SqlCommand cmd = new SqlCommand(query))
                {

                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }

            }
            return view;
        }
    }
}