﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace test4.Models.AdoNet
{
    public class ViewUserData
    {
        private string _connectionString;
        public ViewUserData()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
        }


        public List<ViewData> ViewUser()
        {
            try
            {
                var response = new List<ViewData>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    var query = "SELECT * FROM TestNetAmu";
                    using (SqlCommand cmd = new SqlCommand(query))
                    {
                        cmd.Connection = con;
                        con.Open();

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    response.Add(new ViewData
                                    {
                                        id = reader[0].ToString(),
                                        name = reader[1].ToString(),
                                        surname = reader[2].ToString(),
                                        gender = reader[3].ToString(),
                                        IDNumber = reader[4].ToString()
                                    });
                                }
                            }
                        }

                    }

                }

                return response;

            }
            catch
            {

                throw;
            }
        }
    }
}