﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace test4.Models
{
    public class TestContactInformationData
    {
        public string orderID { get; set; }

        public string date { get; set; }

        public string status { get; set; }

        public string description { get; set; }

        public string item { get; set; }

        public string itemCategory { get; set; }

        public string quantity { get; set; }

        public string total { get; set; }

        public string UserID { get; set; }
    }
}